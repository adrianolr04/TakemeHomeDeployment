package pe.edu.upc.aww.takemehome0_0;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TakemeHome00ApplicationTests {

    @Test
    void contextLoads() {
    }

}
