package pe.edu.upc.aww.takemehome0_0.dtos;

public class showDescriptionDTO {
    private String nameUser;
    private int totalProducts;

    public String getNameUser() {
        return nameUser;
    }

    public void setNameUser(String nameUser) {
        this.nameUser = nameUser;
    }

    public int getTotalProducts() {
        return totalProducts;
    }

    public void setTotalProducts(int totalProducts) {
        this.totalProducts = totalProducts;
    }
}
